#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "contact.h"
#include "file.h"
#include <ctype.h>
#define FILE_NAME "contacts.txt"

/*
 * Function: listContacts
 * Displays all contacts stored in the address book in a formatted table.
 * Parameters:
 * addressBook - pointer to AddressBook structure
 * Returns:
 *   void
 */

void listContacts(AddressBook *addressBook) 
{
    // Check if address book is empty
    if (addressBook->contactCount == 0)
    {
        printf("No contacts available to display.\n");
        return;
    }

    // Table header
    printf("-------------------------------------------------------------------------------\n");
    printf("| %-5s | %-20s | %-15s | %-30s |\n", 
           "SlNo", "Name", "Phone", "Email");
    printf("-------------------------------------------------------------------------------\n");

    // Loop through all contacts and print details
    for (int i = 0; i < addressBook->contactCount; i++)
    {
        printf("| %-5d | %-20.20s | %-15.15s | %-30.30s |\n",
               i + 1,
               addressBook->contacts[i].name,
               addressBook->contacts[i].phone,
               addressBook->contacts[i].email);
    }

    printf("-------------------------------------------------------------------------------\n");
}

/*
 * Function: initialize
 * Initializes the address book and loads contacts from file (if present).
 * Parameters:
 * addressBook - pointer to AddressBook structure
 * Returns:
 *   void
 */

void initialize(AddressBook *addressBook)
{
    addressBook->contactCount = 0;
    loadContactsFromFile(addressBook);
}

void saveContactsToFile(AddressBook *addressBook)
{
    FILE *fp = fopen("contacts.txt","w");

    if(fp == NULL)
    {
        printf("File error\n");
        return;
    }

    for(int i=0;i<addressBook->contactCount;i++)
    {
        fprintf(fp,"%s,%s,%s\n",addressBook->contacts[i].name,addressBook->contacts[i].phone,addressBook->contacts[i].email);
    }

    fclose(fp);
}
void loadContactsFromFile(AddressBook *addressBook)
{
    FILE *fp = fopen("contacts.txt","r");

    if(fp == NULL)
        return;

    while(fscanf(fp,"%[^,],%[^,],%[^\n]\n",
        addressBook->contacts[addressBook->contactCount].name,
        addressBook->contacts[addressBook->contactCount].phone,
        addressBook->contacts[addressBook->contactCount].email) != EOF)
    {
        addressBook->contactCount++;
    }

    fclose(fp);
}
void createContact(AddressBook *addressBook)
{
	/* Define the logic to create a Contacts */
    if (addressBook->contactCount >= MAX_CONTACTS)
    {
        printf("Address book full!\n");
        return;
    }

    char name[50];
    char phone[20];
    char email[50];
    int name_attempts = 3;
    int phone_attempts = 3;
    int email_attempts = 3;
    int name_valid = 0;
    int phone_valid = 0;
    int email_valid = 0;

/*
 * Function: createContact
 * Creates a new contact by taking name, phone, and email from user.
 * Validates each field before storing in address book.
 * Parameters:
 * addressBook - pointer to AddressBook structure
 * Returns:
 *  void
 */

    while (name_attempts--)
    {
        int hasInvalidChar = 0;

        printf("Enter Name: ");
        scanf(" %[^\n]", name);

        int len = strlen(name);

        /* Rule 1: Minimum length check */
        if (len < 4)
        {
            printf("Error: Name must contain at least 4 characters.\n");
            printf("Attempts left: %d\n", name_attempts);
            continue;
        }

        /* Rule 2,3,4: Only alphabets allowed */
        for (int i = 0; name[i] != '\0'; i++)
        {
            if (!isalpha(name[i]))
            {
                hasInvalidChar = 1;
                break;
            }
        }

        if (hasInvalidChar)
        {
            printf("Error: Name should contain only alphabets (A-Z, a-z).\n");
            printf("Attempts left: %d\n", name_attempts);
            continue;
        }

        /* If all conditions satisfied */
        name_valid = 1;
        printf("Name accepted successfully!\n");
        break;
    }

    if (!name_valid)
    {
        printf("Failed to enter valid name.\n");
        return;
    }

/*
 * Function: validatePhone
 * Parameters:
 * addressBook - pointer to AddressBook structure
 * phone       - input phone number string
 * Returns:
 *   1 if valid, 0 if invalid
 */

    while (phone_attempts--)
    {
    int isvalid = 1;

    printf("Enter phone_number (10 digits, starts 6-9): ");
    scanf(" %[^\n]", phone);

    // checking length 
    if (strlen(phone) != 10)
    {
        printf("Error: Phone number must contain exactly 10 digits\n");
        isvalid = 0;
    }

    // checking range
    if (phone[0] < '6' || phone[0] > '9') 
    {
        printf("Error: First digit must be between 6 and 9\n");
        isvalid = 0;
    }

    // checking digits (alphabets + symbols)
    for (int i = 0; phone[i] != '\0'; i++)
    {
        if (!isdigit(phone[i]))
        {
            if (isalpha(phone[i]))
                printf("Error: Alphabets are not allowed in phone number\n");
            else
                printf("Error: Symbols are not allowed in phone number\n");

            isvalid = 0;
            break;
        }
    }
    
    // checking uniqueness
    if (isvalid)
    {
        for (int i = 0; i < addressBook->contactCount; i++)
        {
            if (strcmp(addressBook->contacts[i].phone, phone) == 0)
            {
                printf("Error: Phone number already exists!\n");
                isvalid = 0;
                break;
            }
        }
    }

    if (isvalid)
    {
        phone_valid = 1;
        printf("phone_number accepted successfully!\n");
        break;
    }
    else
    {
        printf("Invalid phone_number! Attempts left: %d\n\n", phone_attempts);
    }
}

if (!phone_valid)
{
    printf("Failed to enter valid phone_number.\n");
    return;
}

/*
 * Function: validateEmailAndStore
 * Validates email based on rules and stores contact if valid.
 * Parameters:
 * addressBook - pointer to AddressBook structure
 * name, phone - already validated
 * Returns:
 *   void
 */

while (email_attempts--)
{
    int isvalid = 1, at_count = 0, dot_count = 0;
    int at_pos = -1, dot_pos = -1;

    printf("Enter email (example: name@gmail.com): ");
    scanf(" %[^\n]", email);

    int len = strlen(email);

    // basic length check
    if (len < 5)
    {
        printf("Error: Email is too short\n");
        isvalid = 0;
    }

    // scan email
    for (int i = 0; email[i]; i++)
    {
        char c = email[i];

        // count @
        if (c == '@')
        {
            at_count++;
            at_pos = i;
        }

        // count .
        if (c == '.')
        {
            dot_count++;
            dot_pos = i;
        }

        // invalid symbols (only @ and . allowed)
        if (!isalnum(c) && c != '@' && c != '.')
        {
            printf("Error: Only '@' and '.' are allowed as symbols\n");
            isvalid = 0;
        }

        // uppercase not allowed
        if (isupper(c))
        {
            printf("Error: Uppercase letters are not allowed\n");
            isvalid = 0;
        }

        // space not allowed
        if (c == ' ')
        {
            printf("Error: Spaces are not allowed in email\n");
            isvalid = 0;
        }
    }

    // rule 1 & 3: exactly one @
    if (at_count != 1)
    {
        printf("Error: Email must contain exactly one '@'\n");
        isvalid = 0;
    }

    // rule 2: at least one dot
    if (dot_count < 1)
    {
        printf("Error: Email must contain at least one '.'\n");
        isvalid = 0;
    }

    // rule 4: dot must be after @
    if (dot_pos < at_pos)
    {
        printf("Error: '.' must appear after '@'\n");
        isvalid = 0;
    }

    // rule 5: at least one character between @ and .
    if (dot_pos == at_pos + 1)
    {
        printf("Error: There must be at least one character between '@' and '.'\n");
        isvalid = 0;
    }

    // rule 6: must end exactly with ".com"
    if (len < 4 || strcmp(&email[len - 4], ".com") != 0)
    {
        printf("Error: Email must end with '.com' and no extra characters allowed\n");
        isvalid = 0;
    }

    // rule 8: after @ and after . only alphanumeric allowed
    for (int i = at_pos + 1; i < len; i++)
    {
        if (email[i] == '.') continue;

        if (!isalnum(email[i]))
        {
            printf("Error: Only alphabets and digits allowed after '@' and '.'\n");
            isvalid = 0;
            break;
        }
    }

    // uniqueness check
    if (isvalid)
    {
        for (int i = 0; i < addressBook->contactCount; i++)
        {
            if (strcmp(addressBook->contacts[i].email, email) == 0)
            {
                printf("Error: Email already exists!\n");
                isvalid = 0;
                break;
            }
        }
    }

    if (isvalid)
    {
        email_valid = 1;
        printf("Email accepted successfully!\n");
        break;
    }

    printf("Invalid email! Attempts left: %d\n\n", email_attempts);
}

if (!email_valid)
    return;

/*------------------------------- STORE ----------------------- */

    Contact *newContact = &addressBook->contacts[addressBook->contactCount];

    strcpy(newContact->name, name);
    strcpy(newContact->phone, phone);
    strcpy(newContact->email, email);

    addressBook->contactCount++;

    printf("Contact saved successfully!\n");

}

/*
 * Function: searchContact
 * Allows user to search contacts using name, phone, or email.
 * Displays all matching records (supports duplicates).
 * Provides menu with exit option and validates user choice.
 * Parameters:
 * addressBook - pointer to AddressBook structure
 * Returns:
 *   void
 */

void searchContact(AddressBook *addressBook)
{
    int choice;
    char key[50];
    int found;

    do
    {
        printf("\nSearch Menu:\n");
        printf("1. Search by Name / Phone / Email\n");
        printf("2. Exit Search\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice)
        {
            case 1:
                printf("Enter name / phone / email to search: ");
                scanf(" %[^\n]", key);

                found = 0;

                for (int i = 0; i < addressBook->contactCount; i++)
                {
                    if (strstr(addressBook->contacts[i].name, key) != NULL ||
                        strstr(addressBook->contacts[i].phone, key) != NULL ||
                        strstr(addressBook->contacts[i].email, key) != NULL)
                    {
                        printf("\nContact %d:\n", found + 1);
                        printf("Name  : %s\n", addressBook->contacts[i].name);
                        printf("Phone : %s\n", addressBook->contacts[i].phone);
                        printf("Email : %s\n", addressBook->contacts[i].email);

                        found++;
                    }
                }

                // Rule 3: no match message
                if (found == 0)
                {
                    printf("No matching contact found!\n");
                }
                else
                {
                    printf("\nTotal matches found: %d\n", found);
                }
                break;

            case 2:
                printf("Exiting search...\n");
                break;

            default:
                printf("Invalid choice! Please try again.\n");
        }

    } while (choice != 2);
}
/*---------------------- EDIT CONTACT-------------------------*/

void editContact(AddressBook *addressBook)
{
    int choice;

    do
    {
        char key[50];
        int indices[100];
        int count = 0;

        printf("\nEdit Menu:\n");
        printf("1. Edit Contact\n");
        printf("2. Exit Edit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        if (choice == 2)
        {
            printf("Exiting edit...\n");
            return;
        }

        printf("Enter name / phone / email to edit: ");
        scanf(" %[^\n]", key);

/* -------------------------- SEARCH CONTACTS ------------------------ */

        for (int i = 0; i < addressBook->contactCount; i++)
        {
            if (strstr(addressBook->contacts[i].name, key) ||
                strstr(addressBook->contacts[i].phone, key) ||
                strstr(addressBook->contacts[i].email, key))
            {
                printf("\n%d. Name  : %s\n", count + 1, addressBook->contacts[i].name);
                printf("   Phone : %s\n", addressBook->contacts[i].phone);
                printf("   Email : %s\n", addressBook->contacts[i].email);

                indices[count++] = i;
            }
        }

        if (count == 0)
        {
            printf("Contact not found!\n");
            continue;
        }

        int select;
        printf("\nEnter which contact to edit (1-%d): ", count);
        scanf("%d", &select);

        if (select < 1 || select > count)
        {
            printf("Invalid choice!\n");
            continue;
        }

        int index = indices[select - 1];

        char name[50], phone[20], email[50];

/* ------------------------ NAME VALIDATION ------------------------------- */

        int name_valid = 0, attempts = 3;

        while (attempts--)
        {
            int isvalid = 1;

            printf("Enter new name (alphabets only): ");
            scanf(" %[^\n]", name);

            for (int i = 0; name[i]; i++)
            {
                if (!isalpha(name[i]) && name[i] != ' ')
                {
                    printf("Error: Name must contain only alphabets\n");
                    isvalid = 0;
                    break;
                }
            }

            if (isvalid)
            {
                name_valid = 1;
                break;
            }
            else
                printf("Invalid name! Attempts left: %d\n", attempts);
        }

        if (!name_valid)
        {
            printf("Failed to update name.\n");
            continue;
        }

/* ------------------------- PHONE VALIDATION ----------------------- */
        int phone_valid = 0;
        attempts = 3;

        while (attempts--)
        {
            int isvalid = 1;

            printf("Enter new phone (10 digits, starts 6-9): ");
            scanf(" %[^\n]", phone);

            if (strlen(phone) != 10)
            {
                printf("Error: Phone must be exactly 10 digits\n");
                isvalid = 0;
            }

            if (phone[0] < '6' || phone[0] > '9')
            {
                printf("Error: First digit must be between 6 and 9\n");
                isvalid = 0;
            }

            for (int i = 0; phone[i]; i++)
            {
                if (!isdigit(phone[i]))
                {
                    if (isalpha(phone[i]))
                        printf("Error: Alphabets not allowed\n");
                    else
                        printf("Error: Symbols not allowed\n");

                    isvalid = 0;
                    break;
                }
            }

            /* uniqueness */
            if (isvalid)
            {
                for (int i = 0; i < addressBook->contactCount; i++)
                {
                    if (i != index &&
                        strcmp(addressBook->contacts[i].phone, phone) == 0)
                    {
                        printf("Error: Phone already exists!\n");
                        isvalid = 0;
                        break;
                    }
                }
            }

            if (isvalid)
            {
                phone_valid = 1;
                break;
            }
            else
                printf("Invalid phone! Attempts left: %d\n", attempts);
        }

        if (!phone_valid)
        {
            printf("Failed to update phone.\n");
            continue;
        }

/*------------------------------ email_validation --------------------------------*/
        int email_valid = 0;
        attempts = 3;

        while (attempts--)
        {
            int isvalid = 1, at_count = 0, dot_count = 0;
            int at_pos = -1, dot_pos = -1;
            int len;

            printf("Enter new email: ");
            scanf(" %[^\n]", email);

            len = strlen(email);

            for (int i = 0; email[i]; i++)
            {
                char c = email[i];

                if (c == '@') { at_count++; at_pos = i; }
                if (c == '.') { dot_count++; dot_pos = i; }

                if (!isalnum(c) && c != '@' && c != '.')
                {
                    printf("Error: Only '@' and '.' allowed\n");
                    isvalid = 0;
                }

                if (isupper(c))
                {
                    printf("Error: Uppercase not allowed\n");
                    isvalid = 0;
                }

                if (c == ' ')
                {
                    printf("Error: Spaces not allowed\n");
                    isvalid = 0;
                }
            }

            if (at_count != 1)
            {
                printf("Error: Must contain exactly one '@'\n");
                isvalid = 0;
            }

            if (dot_count < 1)
            {
                printf("Error: Must contain '.'\n");
                isvalid = 0;
            }

            if (dot_pos < at_pos)
            {
                printf("Error: '.' must be after '@'\n");
                isvalid = 0;
            }

            if (dot_pos == at_pos + 1)
            {
                printf("Error: Invalid domain\n");
                isvalid = 0;
            }

            if (len < 4 || strcmp(&email[len - 4], ".com") != 0)
            {
                printf("Error: Must end with .com\n");
                isvalid = 0;
            }

            /* uniqueness */
            if (isvalid)
            {
                for (int i = 0; i < addressBook->contactCount; i++)
                {
                    if (i != index &&
                        strcmp(addressBook->contacts[i].email, email) == 0)
                    {
                        printf("Error: Email already exists!\n");
                        isvalid = 0;
                        break;
                    }
                }
            }

            if (isvalid)
            {
                email_valid = 1;
                break;
            }
            else
                printf("Invalid email! Attempts left: %d\n", attempts);
        }

        if (!email_valid)
        {
            printf("Failed to update email.\n");
            continue;
        }

/* ----------------------------- UPDATE ----------------------------- */

        strcpy(addressBook->contacts[index].name, name);
        strcpy(addressBook->contacts[index].phone, phone);
        strcpy(addressBook->contacts[index].email, email);

        printf("Contact updated successfully!\n");

    } while (choice != 2);
}

/*
 * Function: deleteContact
 * Allows the user to delete a contact from the address book.
 * User can search using name, phone, or email.
 * If multiple records match, user selects one.
 * Confirmation is taken before deletion.
 * Includes menu with exit option and input validation.
 * Parameters:
 * addressBook - pointer to AddressBook structure
 * Returns:
 *   void
 */

void deleteContact(AddressBook *addressBook)
{
    int choice;

    do
    {
        char key[50];
        int indices[100];
        int count = 0;

        printf("\nDelete Menu:\n");
        printf("1. Delete Contact\n");
        printf("2. Exit Delete\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        if (choice == 2)
        {
            printf("Exiting delete...\n");
            return;
        }

        printf("Enter name / phone / email to delete: ");
        scanf(" %[^\n]", key);

/* ------------------ SEARCH (using strstr for flexibility) ----------------- */

        for (int i = 0; i < addressBook->contactCount; i++)
        {
            if (strstr(addressBook->contacts[i].name, key) ||
                strstr(addressBook->contacts[i].phone, key) ||
                strstr(addressBook->contacts[i].email, key))
            {
                printf("\n%d. Name  : %s\n", count + 1, addressBook->contacts[i].name);
                printf("   Phone : %s\n", addressBook->contacts[i].phone);
                printf("   Email : %s\n", addressBook->contacts[i].email);

                indices[count++] = i;
            }
        }

        if (count == 0)
        {
            printf("Contact not found!\n");
            continue;
        }

        int select;
        printf("\nEnter which contact to delete (1-%d): ", count);
        scanf("%d", &select);

        if (select < 1 || select > count)
        {
            printf("Invalid choice!\n");
            continue;
        }

        int index = indices[select - 1];

/* -------------------------- CONFIRMATION ---------------------------- */

        char confirm;
        printf("Are you sure you want to delete this contact? (y/n): ");
        scanf(" %c", &confirm);

        if (confirm != 'y' && confirm != 'Y')
        {
            printf("Deletion cancelled.\n");
            continue;
        }
        
/* -------------------------- SHIFT DELETE ---------------------------- */

        for (int i = index; i < addressBook->contactCount - 1; i++)
        {
            addressBook->contacts[i] = addressBook->contacts[i + 1];
        }

        addressBook->contactCount--;

        printf("Contact deleted successfully!\n");

    } while (choice != 2);
}